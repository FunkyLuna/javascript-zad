const liczby = [20, 150, 3, 10, 200, 5];
liczby.sort((a, b) => a - b);
console.log(liczby);